import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class Server {
    private static final int PORT = 6000;
    private static final String LOG_FILE_NAME = "log.txt";

    private static Map<String, Double> itemBids = new ConcurrentHashMap<>();
    private static Map<String, String> itemBidders = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(30);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT + ".");

            while (true) {
                Socket socket = serverSocket.accept();

                Runnable clientHandler = () -> {
                    try (PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                         BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                        String request = in.readLine();
                        String ipAddress = socket.getInetAddress().getHostAddress();
                        String response = handleRequest(request, ipAddress);
                        out.println(response);

                        logRequest(ipAddress, request, response);
                    } catch (IOException e) {
                        System.err.println("Error occurred: " + e.getMessage());
                    }
                };
                executor.submit(clientHandler);
            }
        } catch (IOException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }

    private static synchronized String handleRequest(String request, String ipAddress) {
        String[] tokens = request.split("\t");

        try {
            switch (tokens.length) {
                case 1:
                    if (itemBids.putIfAbsent(tokens[0], 0.0) != null) {
                        return "Failure";
                    } else {
                        return "Success";
                    }
                case 2:
                    String itemName = tokens[0];
                    double bid = Double.parseDouble(tokens[1]);
                    if (bid <= 0 || !itemBids.containsKey(itemName)) {
                        return "Failure";
                    }
                    if (bid > itemBids.get(itemName)) {
                        String bidder = itemBidders.put(itemName, ipAddress);
                        itemBids.put(itemName, bid);
                        return "Accepted from " + ipAddress + (bidder != null ? " (previous bidder: " + bidder + ")" : "");
                    } else {
                        return "Rejected";
                    }
                default:
                    return "Failure";
            }
        } catch (Exception e) {
            return "Failure";
        }
    }



    private static void logRequest(String ipAddress, String request, String response) {
        try (FileWriter fileWriter = new FileWriter(LOG_FILE_NAME, true)) {
            // 创建SimpleDateFormat对象，用于将当前时间格式化为指定格式的字符串
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd|HH:mm:ss");
            String timestamp = dateFormat.format(new Date());
    
            // 构造一条日志条目，包括时间戳、IP地址、请求和响应
            String logEntry = timestamp + "|" + ipAddress + "|" + request + "|" + response + "\n";
    
            // 将日志条目写入日志文件
            fileWriter.write(logEntry);
        } catch (IOException e) {
            // 如果写入日志文件时出现异常，则将异常信息打印到控制台
            System.err.println("Error occurred while logging request: " + e.getMessage());
        }
    }
    
}
