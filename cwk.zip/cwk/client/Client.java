import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class Client {
    private static final String SERVER_HOSTNAME = "localhost";
    private static final int SERVER_PORT = 6000;

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java Client <command> [arg1] [arg2]");
            return;
        }
    
        String command = args[0];
    
        ExecutorService executor = Executors.newFixedThreadPool(30);
        Socket socket = null;
        try {
            socket = new Socket(SERVER_HOSTNAME, SERVER_PORT);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    
            out.println(command);
    
            switch (command) {
                case "show":
                    handleShowCommand(in);
                    break;
                case "item":
                    if (args.length < 2) {
                        System.err.println("Usage: item <item name>");
                        break;
                    }
                    handleItemCommand(args[1], out, in);
                    break;
                case "bid":
                    if (args.length < 3) {
                        System.err.println("Usage: bid <item name> <bid value>");
                        break;
                    }
                    handleBidCommand(args[1], args[2], out, in);
                    break;
                default:
                    System.err.println("Unknown command: " + command);
                    break;
            }
        } catch (UnknownHostException e) {
            System.err.println("Error: Unknown host " + SERVER_HOSTNAME);
            System.exit(1);
        } catch (ConnectException e) {
            System.err.println("Error: Could not connect to " + SERVER_HOSTNAME + ":" + SERVER_PORT);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Error occurred: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Unknown error occurred: " + e.getMessage());
            System.exit(1);
        } finally {
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                System.err.println("Error closing socket: " + e.getMessage());
            }
    
            executor.shutdown();
            try {
                if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                System.err.println("Error occurred: " + e.getMessage());
            }
        }
    }
    
    private static void handleShowCommand(BufferedReader in) throws IOException {
        String response;
        boolean itemHeaderReceived = false;
        while ((response = in.readLine()) != null) {
            if (response.startsWith("Item\tCurrent Bid\tBidder IP Address")) {
                System.out.println(response);
                itemHeaderReceived = true;
            } else if (itemHeaderReceived) {
                System.out.println(response);
            } else {
                System.err.println("Error: Malformed server response.");
                return;
            }
        }
    }
    

    private static void handleItemCommand(String itemName, PrintWriter out, BufferedReader in) throws IOException {
        out.println(itemName + "\t0");
        String response = in.readLine();
        handleServerResponse(response);
    }
    
    

    private static void handleBidCommand(String itemName, String bidValue, PrintWriter out, BufferedReader in) throws IOException {
        try {
            double bid = Double.parseDouble(bidValue);
            if (bid < 0) {
                System.err.println("Error: Bid value must be non-negative.");
                return;
            }
            out.println(itemName + "\t" + bid);
            String response = in.readLine();
            handleServerResponse(response);
        } catch (NumberFormatException e) {
            System.err.println("Error: Invalid bid value: " + bidValue);
        }
    }
    
    private static void handleServerResponse(String response) {
        if (response.startsWith("Error:")) {
            System.err.println(response);
        } else {
            System.out.println(response);
        }
    }
    
    
}